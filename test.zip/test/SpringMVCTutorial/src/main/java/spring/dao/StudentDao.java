//package spring.dao;
//
//
//import java.util.List;
//
//import spring.model.Student;
//
//public interface StudentDao {
//
//	Student findById(int id);
//	 
//    void saveStudent(Student Student);
//     
//    List<Student> findAllStudents();
// 
//
//}
