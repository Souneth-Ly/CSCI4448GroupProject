package spring.model;

public class TeacherImplementation extends DatabaseStratagy {

}
