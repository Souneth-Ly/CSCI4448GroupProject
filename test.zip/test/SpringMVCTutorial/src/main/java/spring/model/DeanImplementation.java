package spring.model;

public class DeanImplementation extends DatabaseStratagy {

}
