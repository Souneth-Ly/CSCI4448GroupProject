package spring.model;

public class DatabaseStratagy {

}
