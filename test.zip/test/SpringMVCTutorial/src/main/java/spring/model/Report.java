package spring.model;

public class Report {
	    private String name;
	    private String report;
	    private String grade;
	 
	    public String getName() {
	        return name;
	    }
	 
	    public void setName(String aName) {
	        this.name = aName;
	    }
	 
	    public String getReport() {
	        return report;
	    }
	 
	    public void setReport(String aReport) {
	        this.report = aReport;
	    }
	    public String getGrade() {
	        return grade;
	    }
	 
	    public void setGrade(String aGrade) {
	        this.grade = aGrade;
	    }
}
