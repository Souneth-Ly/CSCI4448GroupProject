package spring.model;

public class Student {

}
