package spring.model;

public class Teacher {
	//private String report;
	
}
