package spring.model;

public class Teacher extends AbstractUser {
	private String report;
	public void displayReport(){
		System.out.print(report);
	}
	public void getStudent(){
		
	}
	public void getClasses(){
		
	}
}
