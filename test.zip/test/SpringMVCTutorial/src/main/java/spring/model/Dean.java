package spring.model;
public class Dean extends AbstractUser {
	//private String lockdownCode;
	private String type="Dean";
	public void addClass(){
		
	}
	public void removeClass(){
		
	}
	public void setTuition(){
		
	}
	public void displayStudentList()
	{
		
	}
	public void displayTeacherList(){
		
	}
	public String getType(){
		return type;
	}
	
}
