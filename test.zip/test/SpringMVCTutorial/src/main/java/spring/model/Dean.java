package spring.model;
public class Dean extends AbstractUser {
	//private String lockdownCode;
	public void addClass(){
		
	}
	public void removeClass(){
		
	}
	public void setTuition(){
		
	}
	public void displayStudentList()
	{
		
	}
	public void displayTeacherList(){
		
	}
}
