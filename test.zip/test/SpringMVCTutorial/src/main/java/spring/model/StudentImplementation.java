package spring.model;

public class StudentImplementation extends DatabaseStratagy {

}
