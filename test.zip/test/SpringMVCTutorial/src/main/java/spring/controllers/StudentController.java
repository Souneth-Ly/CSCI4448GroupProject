package spring.controllers;

public class StudentController {

}
