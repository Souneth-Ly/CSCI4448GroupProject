package spring.controllers;

public class Report {
	    private String name;
	    private String report;
	 
	    public String getName() {
	        return name;
	    }
	 
	    public void setName(String aName) {
	        this.name = aName;
	    }
	 
	    public String getReport() {
	        return report;
	    }
	 
	    public void setReport(String aReport) {
	        this.report = aReport;
	    }
}
