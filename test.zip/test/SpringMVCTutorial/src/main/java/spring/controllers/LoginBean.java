package spring.controllers;

public class LoginBean {

}
