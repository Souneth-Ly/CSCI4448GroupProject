package spring.controllers;

public class TeacherController {

}
