package randomTesting;

public class Testmodel {
	private String greetingText;
	 
	public String getGreetingText() {
		return greetingText;
	}
 
	public void setGreetingText(String greetingText) {
		this.greetingText = greetingText;
	}
}
